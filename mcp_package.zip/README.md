﻿# MCP Package (Single-File)

本包为精简合并版本，主要文件为 `mcp_app.py`，集合了 MCP 服务、批量入库与显微特征抽取三类功能。

## 目录结构
- `mcp_app.py`：主程序（serve / ingest / vision 三种模式）
- `requirements.txt`：依赖
- `.env.example`：配置模板（复制为 `.env` 使用）

## 配置
1) 复制模板：`copy .env.example .env`
2) 按需填写 API / MinIO / PG 等配置项。
3) 如需加载额外环境文件：设置 `MCP_EXTRA_ENV` 指向其路径。

## 使用

启动 MCP 主服务：
```
python mcp_app.py serve --port 8003
```

批量入库（PDF 抽图 → 上传 → 向量化 → 入库）：
```
python mcp_app.py ingest --pdf D:\path\to\file.pdf --mode caption --start-page 1 --max-pages 0
```

启动显微特征抽取服务（PLIP）：
```
python mcp_app.py vision --port 8001
```

## 说明
- `serve` 模式暴露核心 MCP 工具接口。
- `vision` 模式仅提供显微特征抽取工具。
- `ingest` 模式用于离线批量入库。
