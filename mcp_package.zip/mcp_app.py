﻿import argparse
import base64
import io
import os
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import quote

import boto3
import requests
from fastmcp import FastMCP
from pgvector.psycopg import register_vector, Vector
from PIL import Image
from pypdf import PdfReader
import psycopg
from psycopg.rows import dict_row

try:
    import torch
except Exception:
    torch = None

try:
    import open_clip
except Exception:
    open_clip = None

try:
    from transformers import CLIPProcessor, CLIPModel
except Exception:
    CLIPProcessor = None
    CLIPModel = None


# --------------------
# env loading
# --------------------

def load_env_file(env_path: Path) -> None:
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip().strip("'").strip('"')
        if key and key not in os.environ:
            os.environ[key] = value


def load_env_chain() -> None:
    base_dir = Path(__file__).parent
    load_env_file(base_dir / ".env")
    extra = os.getenv("MCP_EXTRA_ENV", "").strip()
    if extra:
        load_env_file(Path(extra))


load_env_chain()


# --------------------
# 配置与全局
# --------------------
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

API_BASE = os.getenv("API_BASE", "").rstrip("/")
API_KEY = os.getenv("API_KEY", "")
EMBED_MODEL = os.getenv("EMBED_MODEL", "BAAI/bge-m3")
VLM_MODEL = os.getenv("VLM_MODEL", "")
LLM_MODEL = os.getenv("LLM_MODEL", "")

MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT", "")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY", "")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY", "")
MINIO_BUCKET = os.getenv("MINIO_BUCKET", "pathology-images")
MINIO_REGION = os.getenv("MINIO_REGION", None) or None
MINIO_SECURE = os.getenv("MINIO_SECURE", "false").lower() == "true"
MINIO_PUBLIC_ENDPOINT = os.getenv("MINIO_PUBLIC_ENDPOINT", "")
MINIO_DATA_DIR = os.getenv("MINIO_DATA_DIR", "").strip()
MINIO_DATA_DIR = Path(MINIO_DATA_DIR) if MINIO_DATA_DIR else None


PLIP_MODEL_ID = os.getenv("PLIP_MODEL_ID", "vinid/plip")
PLIP_TOP_K = int(os.getenv("PLIP_TOP_K", "4"))
PLIP_THRESHOLD = float(os.getenv("PLIP_THRESHOLD", "0.05"))


def normalize_pg_dsn(dsn: str) -> str:
    if dsn.count("@") <= 1 or "://" not in dsn:
        return dsn
    scheme, rest = dsn.split("://", 1)
    userinfo, host_part = rest.rsplit("@", 1)
    if ":" not in userinfo:
        return dsn
    user, password = userinfo.split(":", 1)
    return f"{scheme}://{user}:{quote(password, safe='')}@{host_part}"


PG_DSN = normalize_pg_dsn(os.getenv("PG_DSN", ""))
MCP_PORT = int(os.getenv("MCP_PORT", "8003"))
PLIP_MCP_PORT = int(os.getenv("PLIP_MCP_PORT", "8001"))

OPEN_CLIP_MODEL = os.getenv("OPEN_CLIP_MODEL", "")
OPEN_CLIP_PRETRAINED = os.getenv("OPEN_CLIP_PRETRAINED", "")

VECTOR_DIM = 1024
_TABLES_READY = False
_MINIO_CLIENT = None


mcp = FastMCP("PathologyData Server")
vision_mcp = FastMCP("PathoVision PLIP Server")


# --------------------
# 工具函数
# --------------------

def log(msg: str) -> None:
    print(f"[MCP] {msg}")


def get_pg():
    if not PG_DSN:
        raise RuntimeError("PG_DSN 未配置")
    conn = psycopg.connect(PG_DSN, autocommit=True, row_factory=dict_row)
    register_vector(conn)
    return conn


def to_pgvector(vec: Optional[List[float]]) -> Optional[Vector]:
    if vec is None or isinstance(vec, Vector):
        return vec
    return Vector(vec)


def ensure_tables() -> None:
    global _TABLES_READY
    if _TABLES_READY:
        return
    sql_cases = f"""
    CREATE TABLE IF NOT EXISTS pathology_cases (
        id text PRIMARY KEY,
        image_url text,
        caption text,
        tags text[],
        source_doc text,
        source_page int,
        image_embedding vector({VECTOR_DIM}),
        text_embedding vector({VECTOR_DIM}),
        created_at timestamptz DEFAULT now()
    );
    """
    sql_texts = f"""
    CREATE TABLE IF NOT EXISTS pathology_texts (
        id text PRIMARY KEY,
        doc_name text,
        chunk text,
        page int,
        text_embedding vector({VECTOR_DIM}),
        created_at timestamptz DEFAULT now()
    );
    """
    with get_pg() as conn, conn.cursor() as cur:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        cur.execute(sql_cases)
        cur.execute(sql_texts)
    _TABLES_READY = True
    log("tables ready")


def get_minio_client():
    global _MINIO_CLIENT
    if _MINIO_CLIENT is not None:
        return _MINIO_CLIENT
    if not MINIO_ENDPOINT or not MINIO_ACCESS_KEY:
        raise RuntimeError("MinIO 未配置")
    session = boto3.session.Session()
    _MINIO_CLIENT = session.client(
        "s3",
        endpoint_url=MINIO_ENDPOINT,
        aws_access_key_id=MINIO_ACCESS_KEY,
        aws_secret_access_key=MINIO_SECRET_KEY,
        region_name=MINIO_REGION,
        use_ssl=MINIO_SECURE,
    )
    return _MINIO_CLIENT


def get_public_minio_endpoint() -> str:
    endpoint = MINIO_PUBLIC_ENDPOINT or MINIO_ENDPOINT
    return endpoint.rstrip("/") if endpoint else ""


def to_public_url(url: str) -> str:
    if not url:
        return url
    public_endpoint = get_public_minio_endpoint()
    if not public_endpoint or not MINIO_ENDPOINT:
        return url
    internal_endpoint = MINIO_ENDPOINT.rstrip("/")
    if url.startswith(internal_endpoint + "/"):
        return public_endpoint + url[len(internal_endpoint):]
    return url


def is_s3_path(image_input: str) -> bool:
    return image_input.startswith("s3://") or image_input.startswith("/")


def parse_s3_path(image_input: str) -> Tuple[str, str]:
    raw = image_input
    if image_input.startswith("s3://"):
        raw = image_input[len("s3://"):]
    elif image_input.startswith("/"):
        raw = image_input.lstrip("/")
    if "/" not in raw:
        raise ValueError("S3 path must be in bucket/key format.")
    bucket, key = raw.split("/", 1)
    return bucket, key


def get_s3_client_optional(endpoint_url: Optional[str] = None):
    session = boto3.session.Session()
    endpoint = endpoint_url or MINIO_ENDPOINT or None
    if endpoint or MINIO_ACCESS_KEY or MINIO_SECRET_KEY:
        return session.client(
            "s3",
            endpoint_url=endpoint,
            aws_access_key_id=MINIO_ACCESS_KEY or None,
            aws_secret_access_key=MINIO_SECRET_KEY or None,
            region_name=MINIO_REGION,
            use_ssl=MINIO_SECURE,
        )
    return session.client("s3")


def s3_to_presigned_url(image_input: str, expires: int = 3600) -> str:
    bucket, key = parse_s3_path(image_input)
    client = get_s3_client_optional(endpoint_url=get_public_minio_endpoint() or None)
    return client.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expires,
    )


def get_minio_object_part_path(bucket: str, key: str) -> Optional[Path]:
    if MINIO_DATA_DIR is None:
        return None
    base_dir = MINIO_DATA_DIR / bucket / Path(key)
    if not base_dir.exists():
        return None
    parts = sorted(base_dir.glob("**/part.*"))
    return parts[0] if parts else None


def resolve_image_url(image_input: str) -> str:
    if image_input.startswith("http"):
        return image_input
    if is_s3_path(image_input):
        try:
            return s3_to_presigned_url(image_input)
        except Exception:
            bucket, key = parse_s3_path(image_input)
            part_path = get_minio_object_part_path(bucket, key)
            if part_path:
                return str(part_path)
            return image_input
    path = Path(image_input)
    if path.exists():
        return str(path)
    return image_input


def pad_vector(vec: List[float], dim: int = VECTOR_DIM) -> List[float]:
    if len(vec) == dim:
        return vec
    if len(vec) > dim:
        return vec[:dim]
    return vec + [0.0] * (dim - len(vec))


def call_embedding_api(text: str) -> List[float]:
    if not API_BASE or not API_KEY:
        raise RuntimeError("API_BASE 或 API_KEY 未配置")
    url = f"{API_BASE}/embeddings"
    payload = {"model": EMBED_MODEL, "input": text}
    headers = {"Authorization": f"Bearer {API_KEY}"}
    resp = requests.post(url, json=payload, headers=headers, timeout=30)
    resp.raise_for_status()
    data = resp.json()
    emb = data["data"][0]["embedding"]
    return pad_vector([float(x) for x in emb])


def call_vlm_caption(image_url: str, prompt: Optional[str] = None, max_tokens: int = 256) -> str:
    if not VLM_MODEL:
        return ""
    if not API_BASE or not API_KEY:
        raise RuntimeError("API_BASE 或 API_KEY 未配置")
    url = f"{API_BASE}/chat/completions"
    content: List[Dict[str, Any]] = []
    if prompt:
        content.append({"type": "text", "text": prompt})
    content.append({"type": "image_url", "image_url": {"url": image_url}})
    payload = {
        "model": VLM_MODEL,
        "messages": [{"role": "user", "content": content}],
        "max_tokens": max_tokens,
    }
    headers = {"Authorization": f"Bearer {API_KEY}"}
    resp = requests.post(url, json=payload, headers=headers, timeout=60)
    resp.raise_for_status()
    data = resp.json()
    return data["choices"][0]["message"]["content"]


def load_image_from_url(image_url: str) -> Image.Image:
    resp = requests.get(image_url, stream=True, timeout=30)
    resp.raise_for_status()
    return Image.open(io.BytesIO(resp.content)).convert("RGB")


def load_image_any(image_input: str) -> Image.Image:
    if image_input.startswith("http"):
        return load_image_from_url(image_input)
    if is_s3_path(image_input):
        bucket, key = parse_s3_path(image_input)
        data = b""
        try:
            client = get_s3_client_optional()
            obj = client.get_object(Bucket=bucket, Key=key)
            data = obj["Body"].read()
        except Exception:
            part_path = get_minio_object_part_path(bucket, key)
            if part_path and part_path.exists():
                data = part_path.read_bytes()
        if not data:
            raise FileNotFoundError(f"s3 object not found: {bucket}/{key}")
        return Image.open(io.BytesIO(data)).convert("RGB")
    path = Path(image_input)
    if not path.exists():
        raise FileNotFoundError(image_input)
    return Image.open(path).convert("RGB")


def get_image_embedding_open_clip(image_input: str) -> Optional[List[float]]:
    if open_clip is None or torch is None or not OPEN_CLIP_MODEL or not OPEN_CLIP_PRETRAINED:
        return None
    model, _, preprocess = open_clip.create_model_and_transforms(
        OPEN_CLIP_MODEL, pretrained=OPEN_CLIP_PRETRAINED
    )
    model.eval()
    device = "cuda" if torch.cuda.is_available() else "cpu"
    model = model.to(device)

    image = load_image_any(image_input)
    image_input = preprocess(image).unsqueeze(0).to(device)
    with torch.no_grad():
        image_features = model.encode_image(image_input)
        image_features /= image_features.norm(dim=-1, keepdim=True)
    emb = image_features[0].tolist()
    return pad_vector([float(x) for x in emb])


def upsert_vector_row(
    table: str,
    columns: List[str],
    values: List[Any],
    conflict_target: str = "id",
) -> None:
    placeholders = ", ".join(["%s"] * len(values))
    cols = ", ".join(columns)
    updates = ", ".join([f"{c}=EXCLUDED.{c}" for c in columns if c != conflict_target])
    normalized_values = [
        to_pgvector(val) if col.endswith("_embedding") else val
        for col, val in zip(columns, values)
    ]
    sql = f"""
    INSERT INTO {table} ({cols})
    VALUES ({placeholders})
    ON CONFLICT ({conflict_target}) DO UPDATE SET {updates};
    """
    with get_pg() as conn, conn.cursor() as cur:
        cur.execute(sql, normalized_values)


def query_vector(
    table: str,
    column: str,
    vec: List[float],
    top_k: int = 5,
    extra_condition: str = "",
    params: Optional[List[Any]] = None,
    select_columns: Optional[List[str]] = None,
) -> List[Dict[str, Any]]:
    cond = f"WHERE {extra_condition}" if extra_condition else ""
    vec_param = to_pgvector(vec)
    select_clause = ", ".join(select_columns) if select_columns else "*"
    sql = f"""
    SELECT {select_clause}, {column} <-> %s AS score
    FROM {table}
    {cond}
    ORDER BY {column} <-> %s
    LIMIT %s;
    """
    with get_pg() as conn, conn.cursor() as cur:
        cur.execute(sql, [vec_param] + (params or []) + [vec_param, top_k])
        rows = cur.fetchall()
    return rows


def query_caption_like(
    table: str,
    query: str,
    top_k: int = 5,
    source_doc: str = "",
) -> List[Dict[str, Any]]:
    conditions = ["caption ILIKE %s"]
    params: List[Any] = [f"%{query}%"]
    if source_doc:
        conditions.insert(0, "source_doc = %s")
        params.insert(0, source_doc)
    sql = f"""
    SELECT id, image_url, caption, tags, source_doc, source_page, created_at
    FROM {table}
    WHERE {" AND ".join(conditions)}
    ORDER BY created_at DESC
    LIMIT %s;
    """
    params.append(top_k)
    with get_pg() as conn, conn.cursor() as cur:
        cur.execute(sql, params)
        rows = cur.fetchall()
    return rows


def normalize_image_urls(rows: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    for row in rows:
        image_url = row.get("image_url")
        if image_url:
            row["image_url"] = to_public_url(image_url)
    return rows


def ensure_bucket() -> None:
    client = get_minio_client()
    bucket = MINIO_BUCKET
    try:
        client.head_bucket(Bucket=bucket)
    except Exception:
        client.create_bucket(Bucket=bucket)


# --------------------
# MCP: 数据管线工具
# --------------------

def extract_pdf_images_impl(
    pdf_path: str,
    limit: int = 0,
    start_page: int = 1,
    max_pages: int = 0,
) -> List[Dict[str, Any]]:
    pdf_path = Path(pdf_path)
    if not pdf_path.exists():
        raise FileNotFoundError(pdf_path)
    reader = PdfReader(str(pdf_path))
    out_dir = DATA_DIR / "extracted" / pdf_path.stem
    out_dir.mkdir(parents=True, exist_ok=True)
    results: List[Dict[str, Any]] = []
    total_pages = len(reader.pages)
    start_idx = max(0, start_page - 1)
    end_idx = total_pages if max_pages <= 0 else min(total_pages, start_idx + max_pages)
    for idx in range(start_idx, end_idx):
        page = reader.pages[idx]
        if limit and len(results) >= limit:
            break
        if not getattr(page, "images", None):
            continue
        page_text = (page.extract_text() or "").strip()
        for j, img in enumerate(page.images):
            if limit and len(results) >= limit:
                break
            name = img.name or f"page{idx+1}_img{j+1}"
            ext = ".png"
            save_path = out_dir / f"{name}{ext}"
            pil_img = img.image
            pil_img.save(save_path)
            results.append(
                {
                    "page": idx + 1,
                    "caption": page_text,
                    "local_path": str(save_path),
                    "name": name,
                }
            )
    log(f"extracted {len(results)} images from {pdf_path.name}")
    return results


def extract_pdf_images(
    pdf_path: str,
    limit: int = 0,
    start_page: int = 1,
    max_pages: int = 0,
) -> List[Dict[str, Any]]:
    return extract_pdf_images_impl(pdf_path, limit, start_page, max_pages)


@mcp.tool(
    name="extract_pdf_images",
    description="从PDF抽取图片与页面文本，保存到data/extracted目录下，返回元数据列表。",
)
def extract_pdf_images_tool(
    pdf_path: str,
    limit: int = 0,
    start_page: int = 1,
    max_pages: int = 0,
) -> List[Dict[str, Any]]:
    return extract_pdf_images(pdf_path, limit, start_page, max_pages)


def upload_to_minio_impl(local_path: str, object_key: Optional[str] = None) -> str:
    client = get_minio_client()
    path = Path(local_path)
    if not path.exists():
        raise FileNotFoundError(local_path)
    key = object_key or f"uploads/{uuid.uuid4().hex}{path.suffix}"
    client.upload_file(str(path), MINIO_BUCKET, key)
    public_endpoint = get_public_minio_endpoint()
    url = (
        f"{public_endpoint}/{MINIO_BUCKET}/{key}"
        if public_endpoint
        else f"{MINIO_ENDPOINT.rstrip('/')}/{MINIO_BUCKET}/{key}"
    )
    log(f"uploaded {local_path} -> {url}")
    return url


def upload_to_minio(local_path: str, object_key: Optional[str] = None) -> str:
    return upload_to_minio_impl(local_path, object_key)


@mcp.tool(
    name="upload_to_minio",
    description="上传本地文件到MinIO/S3，返回URL。",
)
def upload_to_minio_tool(local_path: str, object_key: Optional[str] = None) -> str:
    return upload_to_minio(local_path, object_key)


def embed_text_impl(text: str) -> List[float]:
    return call_embedding_api(text)


def embed_text(text: str) -> List[float]:
    return embed_text_impl(text)


@mcp.tool(
    name="embed_text",
    description="调用embeddings接口生成文本向量。",
)
def embed_text_tool(text: str) -> List[float]:
    return embed_text(text)


def embed_image_impl(image_url: str, prompt: str = "") -> Dict[str, Any]:
    resolved_url = resolve_image_url(image_url)
    vlm_caption = ""
    try:
        if resolved_url.startswith("http"):
            vlm_caption = call_vlm_caption(
                resolved_url,
                prompt or "Describe the pathology features of this image briefly.",
                max_tokens=256,
            )
    except Exception as e:
        log(f"VLM caption failed: {e}")

    image_embedding = get_image_embedding_open_clip(resolved_url)
    if image_embedding is None:
        if vlm_caption:
            image_embedding = embed_text_impl(vlm_caption)
        else:
            image_embedding = embed_text_impl("image")

    return {
        "image_embedding": image_embedding,
        "vlm_caption": vlm_caption,
    }


def embed_image(image_url: str, prompt: str = "") -> Dict[str, Any]:
    return embed_image_impl(image_url, prompt)


@mcp.tool(
    name="embed_image",
    description="生成图像embedding（优先本地CLIP），并给出VLM描述。",
)
def embed_image_tool(image_url: str, prompt: str = "") -> Dict[str, Any]:
    return embed_image(image_url, prompt)


def upsert_case_impl(payload: Dict[str, Any]) -> str:
    ensure_tables()
    case_id = payload.get("id") or uuid.uuid4().hex
    image_embedding = payload.get("image_embedding")
    text_embedding = payload.get("text_embedding")
    if image_embedding is not None:
        image_embedding = pad_vector(image_embedding)
    if text_embedding is not None:
        text_embedding = pad_vector(text_embedding)
    cols = [
        "id",
        "image_url",
        "caption",
        "tags",
        "source_doc",
        "source_page",
        "image_embedding",
        "text_embedding",
    ]
    values = [
        case_id,
        payload.get("image_url"),
        payload.get("caption"),
        payload.get("tags"),
        payload.get("source_doc"),
        payload.get("source_page"),
        image_embedding,
        text_embedding,
    ]
    upsert_vector_row("pathology_cases", cols, values)
    return case_id


def upsert_case(payload: Dict[str, Any]) -> str:
    return upsert_case_impl(payload)


@mcp.tool(
    name="upsert_case",
    description="写入/更新病例库，一条记录包含图URL、caption、标签、向量等。",
)
def upsert_case_tool(payload: Dict[str, Any]) -> str:
    return upsert_case(payload)


def ingest_pdf_text_impl(pdf_path: str, doc_name: str, chunk_size: int = 800) -> Dict[str, Any]:
    ensure_tables()
    reader = PdfReader(pdf_path)
    total = 0
    for idx, page in enumerate(reader.pages):
        text = (page.extract_text() or "").strip()
        if not text:
            continue
        chunks: List[str] = []
        current = []
        for line in text.splitlines():
            current.append(line)
            if sum(len(x) for x in current) >= chunk_size:
                chunks.append(" ".join(current))
                current = []
        if current:
            chunks.append(" ".join(current))
        for chunk in chunks:
            emb = embed_text_impl(chunk)
            row_id = uuid.uuid4().hex
            cols = ["id", "doc_name", "chunk", "page", "text_embedding"]
            vals = [row_id, doc_name, chunk, idx + 1, emb]
            upsert_vector_row("pathology_texts", cols, vals)
            total += 1
    return {"status": "ok", "chunks": total}


def ingest_pdf_text(pdf_path: str, doc_name: str, chunk_size: int = 800) -> Dict[str, Any]:
    return ingest_pdf_text_impl(pdf_path, doc_name, chunk_size)


@mcp.tool(
    name="ingest_pdf_text",
    description="切分PDF文本并写入文本库（向量化后存pgvector）。",
)
def ingest_pdf_text_tool(pdf_path: str, doc_name: str, chunk_size: int = 800) -> Dict[str, Any]:
    return ingest_pdf_text(pdf_path, doc_name, chunk_size)


def search_similar_cases_impl(image_url: str, query: str = "", top_k: int = 5) -> Dict[str, Any]:
    ensure_tables()
    emb_result = embed_image_impl(image_url)
    image_emb = pad_vector(emb_result["image_embedding"])
    text_vec = None
    if query:
        text_vec = embed_text_impl(query)
    elif emb_result["vlm_caption"]:
        text_vec = embed_text_impl(emb_result["vlm_caption"])

    case_cols = ["id", "image_url", "caption", "tags", "source_doc", "source_page", "created_at"]
    cases_by_image = query_vector(
        "pathology_cases",
        "image_embedding",
        image_emb,
        top_k=top_k,
        select_columns=case_cols,
    )
    cases_by_image = normalize_image_urls(cases_by_image)
    cases_by_text: List[Dict[str, Any]] = []
    if text_vec is not None:
        cases_by_text = query_vector(
            "pathology_cases",
            "text_embedding",
            text_vec,
            top_k=top_k,
            select_columns=case_cols,
        )
        cases_by_text = normalize_image_urls(cases_by_text)
        text_cols = ["id", "doc_name", "chunk", "page", "created_at"]
        kb_hits = query_vector(
            "pathology_texts",
            "text_embedding",
            text_vec,
            top_k=top_k,
            select_columns=text_cols,
        )
    else:
        kb_hits = []

    return {
        "vlm_caption": emb_result["vlm_caption"],
        "cases_by_image": cases_by_image,
        "cases_by_text": cases_by_text,
        "kb_hits": kb_hits,
    }


def search_similar_cases(image_url: str, query: str = "", top_k: int = 5) -> Dict[str, Any]:
    return search_similar_cases_impl(image_url, query, top_k)


@mcp.tool(
    name="search_similar_cases",
    description="按上传图片（可含文本查询）检索相似病例与文本库。",
)
def search_similar_cases_tool(image_url: str, query: str = "", top_k: int = 5) -> Dict[str, Any]:
    return search_similar_cases(image_url, query, top_k)


def search_pathology_images_impl(query: str, top_k: int = 6, source_doc: str = "") -> Dict[str, Any]:
    ensure_tables()
    if not query.strip():
        return {"status": "error", "message": "query is required"}
    hits: List[Dict[str, Any]] = []
    mode = "caption"
    case_cols = ["id", "image_url", "caption", "tags", "source_doc", "source_page", "created_at"]
    if API_BASE and API_KEY:
        try:
            text_vec = embed_text_impl(query)
            extra = "source_doc = %s" if source_doc else ""
            params = [source_doc] if source_doc else []
            hits = query_vector(
                "pathology_cases",
                "text_embedding",
                text_vec,
                top_k=top_k,
                extra_condition=extra,
                params=params,
                select_columns=case_cols,
            )
            hits = normalize_image_urls(hits)
            mode = "vector"
        except Exception as exc:
            log(f"vector search failed, fallback to caption: {exc}")
            hits = query_caption_like("pathology_cases", query, top_k=top_k, source_doc=source_doc)
            mode = "caption"
        if not hits:
            hits = query_caption_like("pathology_cases", query, top_k=top_k, source_doc=source_doc)
            mode = "caption"
    else:
        hits = query_caption_like("pathology_cases", query, top_k=top_k, source_doc=source_doc)
    hits = normalize_image_urls(hits)
    return {"status": "ok", "query": query, "mode": mode, "hits": hits}


@mcp.tool(
    name="search_pathology_images",
    description="按关键词搜索病理图片，返回image_url和caption。",
)
def search_pathology_images_tool(query: str, top_k: int = 6, source_doc: str = "") -> Dict[str, Any]:
    return search_pathology_images_impl(query, top_k, source_doc)


# --------------------
# MCP: 显微特征抽取
# --------------------

MICRO_CANDIDATE_LABELS = [
    "normal tissue structure",
    "granulomatous inflammation",
    "necrosis",
    "fibrosis or sclerosis",
    "fatty change or steatosis",
    "spindle cell proliferation",
    "squamous cell carcinoma",
    "adenocarcinoma",
    "malignant lymphoma cells",
    "multinucleated giant cells",
    "acute inflammation (neutrophils)",
    "chronic inflammation (lymphocytes)",
    "slit-like vascular spaces",
    "foamy exudate",
    "owl's eye inclusion",
    "fungal yeast forms",
    "extravasated erythrocytes",
    "starry sky pattern",
    "caseous necrosis",
]

_PLIP_MODEL = None
_PLIP_PROCESSOR = None
_PLIP_READY = False


def ensure_plip_ready() -> bool:
    global _PLIP_READY, _PLIP_MODEL, _PLIP_PROCESSOR
    if _PLIP_READY:
        return _PLIP_MODEL is not None and _PLIP_PROCESSOR is not None
    _PLIP_READY = True
    if torch is None or CLIPModel is None or CLIPProcessor is None:
        return False
    try:
        device = "cuda" if torch.cuda.is_available() else "cpu"
        _PLIP_MODEL = CLIPModel.from_pretrained(PLIP_MODEL_ID).to(device)
        _PLIP_PROCESSOR = CLIPProcessor.from_pretrained(PLIP_MODEL_ID)
        log(f"PLIP loaded on {device}")
        return True
    except Exception as exc:
        log(f"PLIP load failed: {exc}")
        return False


@vision_mcp.tool(
    name="extract_microscopic_features",
    description="Extract top microscopic pathology features using PLIP.",
)
def extract_microscopic_features(
    image_url_or_path: str,
    top_k: int = PLIP_TOP_K,
    threshold: float = PLIP_THRESHOLD,
) -> Dict[str, object]:
    if not ensure_plip_ready():
        return {"status": "error", "message": "PLIP model not available."}

    device = "cuda" if torch and torch.cuda.is_available() else "cpu"
    image = load_image_any(image_url_or_path)
    inputs = _PLIP_PROCESSOR(
        text=MICRO_CANDIDATE_LABELS,
        images=image,
        return_tensors="pt",
        padding=True,
    ).to(device)
    with torch.no_grad():
        outputs = _PLIP_MODEL(**inputs)

    probs = outputs.logits_per_image.softmax(dim=1)
    scored: List[Dict[str, float]] = []
    for idx, score in enumerate(probs[0]):
        val = float(score.item())
        if val >= threshold:
            scored.append({"label": MICRO_CANDIDATE_LABELS[idx], "score": val})

    scored.sort(key=lambda x: x["score"], reverse=True)
    scored = scored[: max(1, top_k)]

    return {
        "status": "ok",
        "is_microscopic": len(scored) > 0,
        "top_k": top_k,
        "threshold": threshold,
        "labels": scored,
    }


# --------------------
# 批处理入库
# --------------------

def build_caption(item: Dict[str, str]) -> str:
    caption = (item.get("caption") or "").strip()
    if caption:
        return caption
    name = (item.get("name") or "").strip()
    return name or "webpath image"


def run_ingest(args: argparse.Namespace) -> None:
    ensure_tables()
    ensure_bucket()

    items = extract_pdf_images_impl(
        args.pdf,
        limit=args.limit,
        start_page=args.start_page,
        max_pages=args.max_pages,
    )
    if not items:
        print("No images extracted.")
        return

    processed = 0
    for item in items:
        local_path = item["local_path"]
        image_url = upload_to_minio_impl(
            local_path, object_key=f"webpath/{Path(local_path).name}"
        )

        caption = build_caption(item)
        merged_text = caption
        image_embedding = None
        text_embedding = None
        if args.mode == "vlm":
            img_result = embed_image_impl(image_url)
            image_embedding = img_result["image_embedding"]
            if img_result.get("vlm_caption"):
                merged_text = caption + "\n" + img_result["vlm_caption"]
            text_embedding = embed_text_impl(merged_text)
        elif args.mode == "caption":
            image_embedding = embed_text_impl(caption)
            text_embedding = embed_text_impl(merged_text)
        else:
            image_embedding = None
            text_embedding = None

        payload = {
            "image_url": image_url,
            "caption": caption,
            "tags": [],
            "source_doc": Path(args.pdf).name,
            "source_page": item.get("page"),
            "image_embedding": image_embedding,
            "text_embedding": text_embedding,
        }
        upsert_case_impl(payload)
        processed += 1
        if processed % 5 == 0:
            print(f"Processed {processed}/{len(items)}")

    print(f"Done. Processed {processed} images.")


# --------------------
# CLI
# --------------------

def main() -> None:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="cmd", required=True)

    serve = sub.add_parser("serve", help="start MCP server")
    serve.add_argument("--host", default="0.0.0.0")
    serve.add_argument("--port", type=int, default=MCP_PORT)

    vision = sub.add_parser("vision", help="start microscopic feature server")
    vision.add_argument("--host", default="0.0.0.0")
    vision.add_argument("--port", type=int, default=PLIP_MCP_PORT)

    ingest = sub.add_parser("ingest", help="batch ingest from PDF")
    ingest.add_argument("--pdf", required=True, help="path to pdf")
    ingest.add_argument("--limit", type=int, default=20, help="process first N images (0 = all)")
    ingest.add_argument("--mode", choices=["vlm", "caption", "noembed"], default="caption")
    ingest.add_argument("--start-page", type=int, default=1, help="1-based start page")
    ingest.add_argument("--max-pages", type=int, default=0, help="process at most N pages (0 = all)")

    args = parser.parse_args()
    if args.cmd == "serve":
        log(f"Starting MCP server on port {args.port} ...")
        mcp.run(transport="sse", host=args.host, port=args.port)
    elif args.cmd == "vision":
        log(f"Starting PLIP server on port {args.port} ...")
        vision_mcp.run(transport="sse", host=args.host, port=args.port)
    elif args.cmd == "ingest":
        run_ingest(args)


if __name__ == "__main__":
    main()
